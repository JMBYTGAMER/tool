import os
import sys
import subprocess
import shutil
import traceback
import random
import string
import re
import asyncio
import httpx
import tls_client
import time
import yaml
import warnings
import logging
import json
import base64
import email
import codecs
import datetime
from datetime import datetime
from dataclasses import dataclass, field
from threading import Thread
from pathlib import Path
from typing import Optional, Dict

from colorama import Fore, Style, init
from pystyle import Colors, Colorate, Center
import zipfile
import io
from PIL import Image
from curl_cffi import requests

init(autoreset=True)

def is_domain_blacklisted(domain):
    if not domain:
        return False
    domain = domain.lower()
    blacklist_suffixes = [".store", ".ng"]
    blacklist_domains = ["cybertemp.xyz","duckmail.sbs", "altmails.icu"]
    if domain in blacklist_domains:
        return True
    for suffix in blacklist_suffixes:
        if domain.endswith(suffix):
            return True
    return False

warnings.filterwarnings("ignore")
logging.getLogger().setLevel(logging.CRITICAL)


def log_event(level, message):
    ts = datetime.now().strftime("%H:%M:%S")
    labels = {
        "SUCCESS": f"{Style.BRIGHT}{Fore.GREEN}[ SUCCESS ]{Style.RESET_ALL}",
        "ERROR":   f"{Style.BRIGHT}{Fore.RED}[  ERROR  ]{Style.RESET_ALL}",
        "INFO":    f"{Style.BRIGHT}{Fore.BLUE}[  INFO   ]{Style.RESET_ALL}",
        "WARNING": f"{Style.BRIGHT}{Fore.YELLOW}[ WARNING ]{Style.RESET_ALL}",
        "INPUT":   f"{Style.BRIGHT}{Fore.MAGENTA}[  INPUT  ]{Style.RESET_ALL}",
    }
    label = labels.get(level.upper(), f"{Style.BRIGHT}{Fore.WHITE}[ {level.upper().center(7)} ]{Style.RESET_ALL}")
    print(f"{Fore.LIGHTBLACK_EX}[{ts}]{Style.RESET_ALL} {label}  {Fore.LIGHTWHITE_EX}{message}{Style.RESET_ALL}")


def hl(text):
    """Highlight important values like email, names, IP addresses."""
    return f"{Style.BRIGHT}{Fore.LIGHTCYAN_EX}{text}{Style.RESET_ALL}"


def hl_token(text):
    """Highlight sensitive or token values in bright yellow/amber."""
    return f"{Style.BRIGHT}{Fore.LIGHTYELLOW_EX}{text}{Style.RESET_ALL}"


def log_token(token_masked):
    ts = datetime.now().strftime("%H:%M:%S")
    label = f"{Style.BRIGHT}{Fore.GREEN}[ SUCCESS ]{Style.RESET_ALL}"
    prefix = f"{Fore.LIGHTWHITE_EX}Token Authenticated: {Style.RESET_ALL}"
    token_part = hl_token(token_masked)
    print(f"{Fore.LIGHTBLACK_EX}[{ts}]{Style.RESET_ALL} {label}  {prefix}{token_part}")


def prompt_user(query):
    now = datetime.now().strftime("%H:%M:%S")
    formatted = f"{Fore.LIGHTBLACK_EX}[{now}]{Style.RESET_ALL} {Style.BRIGHT}{Fore.MAGENTA}[  INPUT  ]{Style.RESET_ALL}  {Fore.LIGHTWHITE_EX}{query}{Style.RESET_ALL}"
    return input(formatted)

def install_requirements():
    if os.path.exists("requirements.txt"):
        choice = prompt_user("Do you wish to install required dependencies? (y/n): ").strip().lower()
        if choice == 'y':
            log_event("INFO", "Initializing dependency installation, please stand by...")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
                log_event("SUCCESS", "Dependencies installed successfully.")
            except subprocess.CalledProcessError:
                log_event("ERROR", "Failed to install dependencies automatically. Please install them manually.")
        else:
            log_event("WARNING", "Bypassing dependency installation sequence.")


install_requirements()

try:
    if sys.stdout and sys.stdout.encoding and sys.stdout.encoding.lower() != 'utf-8':
        try:
            sys.stdout.reconfigure(encoding='utf-8')
        except AttributeError:
            sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
    import asyncio
    import truedriver as uc
except Exception as e:
    with open("startup_error.txt", "w", encoding="utf-8") as f:
        f.write(f"IMPORT ERROR: {str(e)}\n\n")
        f.write(traceback.format_exc())
    log_event("ERROR", "Fatal exception encountered during startup initialization.")
    log_event("ERROR", f"{str(e)}")
    log_event("INFO", "Detailed diagnostic log archived to 'startup_error.txt'.")
    prompt_user("Press Enter to terminate execution...")
    sys.exit(1)

@dataclass
class UTILS_DISCORD:
    x_super_properties: dict = field(default_factory=dict)
    discord_user_agent: str = ""
    browser_user_agent: str = ""

    def __init__(self):
        self._scrape_info()
        Thread(target=self._scrape_info_loop, daemon=True).start()

    def _scrape_info(self):
        try:
            session = tls_client.Session(
                client_identifier="chrome_131",
                random_tls_extension_order=True
            )
            response = session.get("https://discord.eintim.dev/discord_info")
            if response.status_code == 200:
                details = response.json()
                self.discord_user_agent = details["desktop"]["user-agent"]
                self.browser_user_agent = details["browser"]["user-agent"]
                self.x_super_properties = details["desktop"]["decoded-x-super-properties"]
            else:
                self._set_fallback_values()
        except:
            self._set_fallback_values()

    def _set_fallback_values(self):
        self.discord_user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9220 Chrome/128.0.6613.186 Electron/32.2.7 Safari/537.36"
        self.browser_user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36"
        self.x_super_properties = {
            "os": "Windows",
            "browser": "Discord Client",
            "release_channel": "stable",
            "client_version": "1.0.9220",
            "os_version": "10.0.26100",
            "os_arch": "x64",
            "app_arch": "x64",
            "system_locale": "en-US",
            "has_client_mods": False,
            "browser_user_agent": self.discord_user_agent,
            "browser_version": "32.2.7",
            "os_sdk_version": "26100",
            "client_build_number": 485097,
            "native_build_number": 73818,
            "client_event_source": None
        }

    def _scrape_info_loop(self):
        while True:
            time.sleep(300)
            try:
                self._scrape_info()
            except:
                pass


def get_path(relative_path):
    if getattr(sys, 'frozen', False) or '__compiled__' in globals():
        base_path = os.path.dirname(os.path.abspath(sys.executable))
    else:
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)


_UTILS_DISCORD = UTILS_DISCORD()
try:
    from groq import Groq
    GROQ_AVAILABLE = True
except ImportError:
    GROQ_AVAILABLE = False


NOPECHA_EXT_ID = "dknlfmjaanfblgfdfebhijalfmhmjjjo"
NOPECHA_EXT_DIR = Path(get_path("extension/nopecha_ext"))
NOPECHA_KEYS_FILE = Path(get_path("config/nopecha.txt"))
NOPECHA_KEY_INDEX = 0

def load_nopecha_keys() -> list:
    if not NOPECHA_KEYS_FILE.exists():
        NOPECHA_KEYS_FILE.parent.mkdir(parents=True, exist_ok=True)
        NOPECHA_KEYS_FILE.write_text("")
        return []
    keys = []
    for line in NOPECHA_KEYS_FILE.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith('#'):
            keys.append(line)
    return keys


def get_current_nopecha_key() -> Optional[str]:
    keys = load_nopecha_keys()
    if not keys:
        return None
    global NOPECHA_KEY_INDEX
    return keys[NOPECHA_KEY_INDEX % len(keys)]


def inject_nopecha_key(api_key: str):
    if not api_key or not NOPECHA_EXT_DIR.exists():
        return False
    settings_path = NOPECHA_EXT_DIR / "settings.json"
    ok = False
    try:
        settings = {}
        if settings_path.exists():
            with open(settings_path, 'r') as f:
                settings = json.load(f)
        settings['key'] = api_key
        with open(settings_path, 'w') as f:
            json.dump(settings, f)
        ok = True
    except:
        pass
    replacement = f'key:me(ge(),{json.dumps(api_key)})'
    pattern = re.compile(r'key:me\(ge\(\),"(?:[^"\\\\]|\\\\.)*"\)')
    try:
        for bundle_path in NOPECHA_EXT_DIR.rglob("*.js"):
            try:
                bundle = bundle_path.read_text(encoding="utf-8", errors="ignore")
                new_bundle, count = pattern.subn(replacement, bundle, count=1)
                if count:
                    bundle_path.write_text(new_bundle, encoding="utf-8")
                    ok = True
            except:
                continue
    except:
        pass
    return ok


def download_nopecha_ext() -> Optional[Path]:
    if NOPECHA_EXT_DIR.exists() and (NOPECHA_EXT_DIR / "manifest.json").exists():
        return NOPECHA_EXT_DIR
    log_event("INFO", "Acquiring NopeCHA extension package (initial execution)...")
    crx_url = f"https://clients2.google.com/service/update2/crx?response=redirect&prodversion=120.0.0.0&acceptformat=crx2,crx3&x=id%3D{NOPECHA_EXT_ID}%26uc"
    try:
        with httpx.Client(follow_redirects=True) as client:
            r = client.get(crx_url, headers={"User-Agent": "Mozilla/5.0"}, timeout=60)
            if r.status_code != 200:
                log_event("ERROR", f"NopeCHA download failed with HTTP status code {r.status_code}.")
                return None
            data = r.content
        if data[:4] == b"Cr24":
            version = int.from_bytes(data[4:8], "little")
            zip_start = (12 + int.from_bytes(data[8:12], "little")) if version == 3 else (16 + int.from_bytes(data[8:12], "little") + int.from_bytes(data[12:16], "little"))
        else:
            zip_start = 0
        NOPECHA_EXT_DIR.mkdir(exist_ok=True, parents=True)
        with zipfile.ZipFile(io.BytesIO(data[zip_start:])) as z:
            z.extractall(NOPECHA_EXT_DIR)
        if (NOPECHA_EXT_DIR / "manifest.json").exists():
            log_event("SUCCESS", "NopeCHA extension successfully deployed.")
            return NOPECHA_EXT_DIR
        log_event("ERROR", "NopeCHA extraction failed: manifest.json descriptor missing.")
        return None
    except Exception as e:
        log_event("ERROR", f"NopeCHA download encountered an exception: {str(e)[:100]}")
        return None


async def setup_nopecha(log_func=None):
    _l = log_func or log_event
    ext_path = download_nopecha_ext()
    if not ext_path:
        _l("ERROR", "Failed to acquire NopeCHA extension framework.")
        return None
    current_key = get_current_nopecha_key()
    if current_key:
        if inject_nopecha_key(current_key):
            _l("SUCCESS", "NopeCHA authentication key successfully injected.")
        else:
            _l("WARNING", "NopeCHA key injection failed; please inspect extension directory permissions.")
    else:
        _l("WARNING", "No NopeCHA authentication key detected in config/nopecha.txt. Automated solving will be constrained.")
    return ext_path

def get_brave_path() -> Optional[str]:
    paths = [
        r"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe",
        r"C:\Program Files (x86)\BraveSoftware\Brave-Browser\Application\brave.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\BraveSoftware\Brave-Browser\Application\brave.exe"),
    ]
    for p in paths:
        if os.path.exists(p):
            return p
    return None


class GroqCaptchaSolver:
    def __init__(self, api_key: str):
        if not GROQ_AVAILABLE:
            raise ImportError("Groq library is not installed.")
        self.client = Groq(api_key=api_key)
        self.model = "llama-3.2-90b-vision-preview"

    def solve_text_captcha(self, image_base64: str) -> Optional[str]:
        try:
            resp = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_base64}"}},
                            {"type": "text", "text": "Extract ONLY the text from this CAPTCHA."}
                        ]
                    }
                ],
                temperature=0.1,
                max_tokens=100
            )
            return resp.choices[0].message.content.strip().replace('"', '').replace('.', '')
        except:
            return None


JS_UTILS = '''
(() => {
    if (window.utils) return; 
    window.utils = {
        setInput: (s, v) => { const el = document.querySelector(s); if(el){ el.value=v; el.dispatchEvent(new Event('input',{bubbles:true})); el.dispatchEvent(new Event('change',{bubbles:true})); }},
        clickAllCheckboxes: () => { 
            const cbs = document.querySelectorAll('input[type="checkbox"]'); 
            let c=0; cbs.forEach(cb => { if(!cb.checked){ cb.click(); cb.checked=true; cb.dispatchEvent(new Event('change',{bubbles:true})); c++; }});
            return {clicked:c, total:cbs.length};
        },
        clickElement: (s) => { const el = document.querySelector(s); if(el) el.click(); }
    };
})();
'''


try:
    loop = asyncio.get_event_loop()
except RuntimeError:
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)


loop.set_exception_handler(lambda loop, context: None)

async def animated_cooldown(total_seconds):
    import sys
    bar_width = 30
    start = time.time()
    while True:
        elapsed = time.time() - start
        remaining = max(0, total_seconds - elapsed)
        if total_seconds > 0:
            progress = min(elapsed / total_seconds, 1.0)
        else:
            progress = 1.0
        filled = round(bar_width * progress)
        bar_filled = Fore.BLUE + chr(9608) * filled + Style.RESET_ALL
        bar_empty = Fore.LIGHTBLACK_EX + chr(9617) * (bar_width - filled) + Style.RESET_ALL
        spin_chars = ['|', '/', '-', '\\']
        spin = Fore.CYAN + spin_chars[int(elapsed * 4) % len(spin_chars)] + Style.RESET_ALL
        label = Fore.YELLOW + 'Cooldown Period' + Style.RESET_ALL
        timer = Fore.WHITE + f'{remaining:.0f}s' + Style.RESET_ALL
        line = f'\r [{datetime.now().strftime("%H:%M:%S")}] {Style.BRIGHT}{Fore.BLUE}[  WAIT   ]{Style.RESET_ALL} {spin} {label} [{bar_filled}{bar_empty}] {timer} remaining   '
        sys.stdout.write(line)
        sys.stdout.flush()
        if remaining <= 0:
            break
        await asyncio.sleep(0.15)
    done_line = f'\r [{datetime.now().strftime("%H:%M:%S")}] {Style.BRIGHT}{Fore.GREEN}[ SUCCESS ]{Style.RESET_ALL} {Fore.WHITE}Cooldown sequence completed.{Style.RESET_ALL}' + ' ' * 40
    sys.stdout.write(done_line + '\n')
    sys.stdout.flush()


def print_stats_bar(valid, locked, invalid):
    total = valid + locked + invalid
    ts = datetime.now().strftime("%H:%M:%S")
    label = f"{Style.BRIGHT}{Fore.BLUE}[ STATS   ]{Style.RESET_ALL}"
    stats_text = f"{Fore.GREEN}Valid: {valid} {Fore.LIGHTBLACK_EX}| {Fore.YELLOW}Locked: {locked} {Fore.LIGHTBLACK_EX}| {Fore.RED}Invalid: {invalid} {Fore.LIGHTBLACK_EX}| {Fore.CYAN}Total: {total}{Style.RESET_ALL}"
    print(f"{Fore.LIGHTBLACK_EX}[{ts}]{Style.RESET_ALL} {label}  {stats_text}")


def set_console_title(title="Token Generator Engine"):
    if os.name == 'nt':
        os.system(f"title {title}")
    else:
        print(f"\33]0;{title}\a", end='', flush=True)


def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')


def cleanup_resources():
    try:
        import gc
        gc.collect()
        try:
            import truedriver as uc
            uc.stop_all()
        except:
            pass
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        tasks = [t for t in asyncio.all_tasks(loop) if not t.done()]
        for t in tasks:
            try: t.cancel()
            except: pass
        gc.collect()
    except:
        pass


async def shutdown_engine():
    try:
        import gc
        gc.collect()
        try:
            import truedriver as uc
            uc.stop_all()
        except:
            pass
        await asyncio.sleep(0.3)
        try:
            loop = asyncio.get_running_loop()
            tasks = [t for t in asyncio.all_tasks(loop) if not t.done()]
            for t in tasks:
                try: t.cancel()
                except: pass
        except RuntimeError:
            pass
        gc.collect()
    except:
        pass


def animate_text(text, speed=0.03):
    lines = text.split('\n')
    for line in lines:
        print(line)
        time.sleep(speed)


def apply_gradient(lines, color_start=(255, 0, 255), color_end=(0, 255, 255)):
    total = len(lines)
    result = []
    for i, line in enumerate(lines):
        r = color_start[0] + (color_end[0] - color_start[0]) * i // max(1, total - 1)
        g = color_start[1] + (color_end[1] - color_start[1]) * i // max(1, total - 1)
        b = color_start[2] + (color_end[2] - color_start[2]) * i // max(1, total - 1)
        result.append(f'\033[38;2;{r};{g};{b}m{line}\033[0m')
    return result


def show_interface():
    pass

async def fetch_discord_token(email: str, password: str, proxy_config: Dict = None) -> str:
    url = "https://discord.com/api/v9/auth/login"
    payload = {
        "login": email,
        "password": password,
        "undelete": False,
        "gift_code_sku_id": None,
        "login_source": None
    }
    
    headers = get_headers()
    
    session = tls_client.Session(
        client_identifier="chrome_131",
        random_tls_extension_order=True
    )
    
    if proxy_config:
        session.proxies = proxy_config

    try:
        response = session.post(
            url,
            headers=headers,
            json=payload,
            timeout_seconds=30
        )
        if response.status_code == 200:
            return response.json().get("token")
        else:
            log_event("ERROR", f"Authentication failed: HTTP {response.status_code} - {response.text}")
    except Exception as e:
        log_event("ERROR", f"Token retrieval exception: {str(e)}")
    return None


def get_headers():
    return {
        "accept": "*/*",
        "accept-language": "en-US,en;q=0.9",
        "content-type": "application/json",
        "origin": "https://discord.com",
        "priority": "u=1, i",
        "referer": "https://discord.com/channels/@me",
        "sec-ch-ua": '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "x-discord-timezone": "Asia/Calcutta",
        "x-super-properties": "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiaGFzX2NsaWVudF9tb2RzIjpmYWxzZSwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEzNC4wLjAuMCBTYWZhcmkvNTM3LjM2IiwiYnJvd3Nlcl92ZXJzaW9uIjoiMTM0LjAuMC4wIiwib3NfdmVyc2lvbiI6IjEwIiwicmVmZXJyZXIiOiIiLCJyZWZlcnJpbmdfZG9tYWluIjoiIiwicmVmZXJyZXJfY3VycmVudCI6IiIsInJlZmVycmluZ19kb21haW5fY3VycmVudCI6IiIsInJlbGVhc2VfY2hhbm5lbCI6InN0YWJsZSIsImNsaWVudF9idWlsZF9udW1iZXIiOjM4NDg4NywiY2xpZW50X2V2ZW50X3NvdXJjZSI6bnVsbH0="
    }


def create_random_string(length=10):
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(length))


def make_handle():
    adjectives = [
        "dark", "cool", "epic", "mega", "ultra", "pro", "elite", "alpha",
        "sigma", "shadow", "void", "ghost", "neon", "cyber", "pixel", "frost",
        "lunar", "solar", "nova", "zen", "sky", "storm", "river", "mountain",
        "silent", "hidden", "lost", "mythic", "iron", "golden", "vivid"
    ]
    nouns = [
        "gamer", "warrior", "ninja", "king", "lord", "knight", "beast",
        "titan", "scout", "pilot", "vortex", "blade", "seeker", "walker",
        "hunter", "reaper", "phantom", "spirit", "dragon", "wolf", "raven"
    ]
    connectors = ["", "_", "."]
    name_parts = [random.choice(adjectives), random.choice(nouns)]
    if random.random() > 0.7:
        name_parts.insert(1, random.choice(adjectives))
    sep = random.choice(connectors)
    name = sep.join(name_parts)
    suffix = str(random.randint(1000, 999999))
    if random.random() > 0.5:
        name += random.choice(connectors) + suffix
    else:
        name += suffix
    return name[:32].lower()

MULLVADEXE = None

MULLVADCOUNTRIES = [
    "us", "ca", "gb", "au", "de", "fr", "nl", "se", "no", "dk",
    "fi", "at", "be", "ie", "jp", "sg", "nz", "za"
]

MULLVADLAST_COUNTRY = None
MULLVADUSED_COUNTRIES = []


def findmullvad_cli():
    in_path = shutil.which("mullvad")
    if in_path:
        return in_path
    root = r"C:\Program Files\Mullvad VPN"
    candidates = [
        os.path.join(root, "mullvad.exe"),
        os.path.join(root, "resources", "bin", "mullvad.exe"),
        os.path.join(root, "resources", "mullvad.exe"),
        os.path.join(root, "bin", "mullvad.exe"),
        os.path.expandvars(r"%LOCALAPPDATA%\Programs\Mullvad VPN\mullvad.exe"),
        os.path.expandvars(r"%LOCALAPPDATA%\Programs\Mullvad VPN\resources\bin\mullvad.exe"),
    ]
    for p in candidates:
        if os.path.exists(p):
            return p
    return None


MULLVADEXE = findmullvad_cli()


def runmullvad(args, timeout=30):
    si = None
    cf = 0
    if os.name == "nt":
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0
        cf = 0x08000000
    exe = MULLVADEXE or "mullvad"
    try:
        proc = subprocess.run(
            [exe, *args],
            capture_output=True,
            text=True,
            timeout=timeout,
            startupinfo=si,
            creationflags=cf if cf else 0
        )
        return proc.returncode, (proc.stdout or "").strip(), (proc.stderr or "").strip()
    except Exception as e:
        return -1, "", str(e)


def mullvadstatus():
    rc, out, _ = runmullvad(["status"], timeout=15)
    return rc, out


def mullvadis_connected(status_text):
    if not status_text:
        return False
    lower = status_text.lower()
    first_line = lower.splitlines()[0] if lower.splitlines() else lower
    return ("tunnel status: connected" in lower
            or (first_line.strip().startswith("connected") and "disconnected" not in first_line)
            or re.search(r"^\s*connected\b", lower, re.M))


def mullvadcountry_from_status(text):
    if not text:
        return None
    m = re.search(r"Relay\s+-\s+([A-Za-z]{2})", text)
    if m:
        return m.group(1).lower()
    m = re.search(r"Visible location:\s*([A-Za-z ]+),\s*([A-Za-z ]+)", text)
    if m:
        country_name = m.group(2).strip().lower()
        map_ = {
            "sweden": "se", "united states": "us", "usa": "us",
            "germany": "de", "netherlands": "nl", "france": "fr", "united kingdom": "gb",
            "england": "gb", "uk": "gb", "canada": "ca", "japan": "jp", "singapore": "sg",
            "australia": "au", "norway": "no", "denmark": "dk", "finland": "fi", "spain": "es",
            "italy": "it", "switzerland": "ch", "austria": "at", "belgium": "be", "ireland": "ie",
            "portugal": "pt", "poland": "pl", "czech republic": "cz", "romania": "ro",
            "new zealand": "nz", "brazil": "br", "india": "in", "south africa": "za",
            "hong kong": "hk", "turkey": "tr"
        }
        return map_.get(country_name)
    return None


def get_public_ip():
    urls = [
        "https://api.ipify.org?format=json",
        "https://ipinfo.io/json",
        "https://ifconfig.co/json",
        "https://am.i.mullvad.net/json"
    ]
    for url in urls:
        try:
            session = tls_client.Session(client_identifier="chrome_131", random_tls_extension_order=True)
            r = session.get(url, timeout_seconds=3)
            if r.status_code == 200:
                data = r.json()
                ip = data.get("ip")
                if ip and re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", ip):
                    return ip
        except:
            continue
    return None


def redact_ip(ip):
    if not ip:
        return "?.?.?.?"
    parts = ip.split(".")
    if len(parts) != 4:
        return ip
    parts[2] = "*"
    parts[3] = "*"
    return ".".join(parts)


def mullvadrandom_country():
    global MULLVADLAST_COUNTRY, MULLVADUSED_COUNTRIES
    avoid_count = min(8, max(0, len(MULLVADCOUNTRIES) - 1))
    avoid_set = set(MULLVADUSED_COUNTRIES[-avoid_count:]) if avoid_count else set()
    pool = [c for c in MULLVADCOUNTRIES if c not in avoid_set]
    if not pool:
        pool = MULLVADCOUNTRIES[:]
        MULLVADUSED_COUNTRIES = []
    pick = random.choice(pool)
    MULLVADLAST_COUNTRY = pick
    MULLVADUSED_COUNTRIES.append(pick)
    if len(MULLVADUSED_COUNTRIES) > 20:
        MULLVADUSED_COUNTRIES = MULLVADUSED_COUNTRIES[-12:]
    return pick


async def mullvad_ensure_connected():
    if not MULLVADEXE:
        log_event("ERROR", "Mullvad CLI binary not detected within system path or program directories.")
        return False
    rc, status = mullvadstatus()
    baseline_ip = get_public_ip()
    log_event("INFO", f"Baseline network IP established: {hl(redact_ip(baseline_ip))}")
    runmullvad(["lockdown-mode", "set", "on"], timeout=20)
    if mullvadis_connected(status):
        c = mullvadcountry_from_status(status)
        log_event("SUCCESS", f"Mullvad VPN active on {hl(redact_ip(baseline_ip))}" + (f" ({hl(c)})" if c else ""))
        return True
    log_event("INFO", "Initiating Mullvad VPN connection protocol...")
    rc, out, err = runmullvad(["connect"], timeout=45)
    last_shown_ip = None
    for i in range(1, 501):
        await asyncio.sleep(0.2)
        rc2, s = mullvadstatus()
        if i % 10 == 0 or not last_shown_ip:
            current_ip = get_public_ip()
            if current_ip != last_shown_ip:
                last_shown_ip = current_ip
        if mullvadis_connected(s):
            connected_count = 1
            for _verify in range(4):
                await asyncio.sleep(0.4)
                _rc, _s = mullvadstatus()
                if mullvadis_connected(_s):
                    connected_count += 1
            if connected_count >= 3:
                ip = last_shown_ip or get_public_ip()
                c = mullvadcountry_from_status(s)
                log_event("SUCCESS", f"Mullvad VPN connected successfully: {hl(redact_ip(ip))}" + (f" ({hl(c)})" if c else ""))
                return True
    runmullvad(["lockdown-mode", "set", "off"], timeout=20)
    final_ip = get_public_ip()
    log_event("ERROR", f"Mullvad connection failed [{rc}]: {err or out} (Final IP: {hl(redact_ip(final_ip))})")
    return False


async def mullvad_cycle(old_ip=None, max_attempts=5):
    global MULLVADLAST_COUNTRY
    if not MULLVADEXE or not os.path.exists(MULLVADEXE):
        log_event("WARNING", "Mullvad CLI unavailable; defaulting to 10s cooldown pause.")
        await asyncio.sleep(10)
        return None
    previous = old_ip or get_public_ip()
    last_ip = previous
    for attempt in range(1, max_attempts + 1):
        country = mullvadrandom_country()
        log_event("INFO", f"Switching VPN relay location to '{hl(country)}' (Attempt {attempt}/{max_attempts})")
        rc, out, err = runmullvad(["relay", "set", "location", country])
        if rc != 0:
            runmullvad(["relay", "set", "location"])
        rc, out, err = runmullvad(["connect"])
        log_event("INFO", "Establishing tunnel connection...")
        deadline = time.time() + 25
        new_ip = None
        last_shown = None
        poll_i = 0
        while time.time() < deadline:
            poll_i += 1
            await asyncio.sleep(0.3)
            new_ip = get_public_ip()
            if new_ip and new_ip != last_shown:
                last_shown = new_ip
            if new_ip and new_ip != last_ip:
                break
        if mullvadis_connected(mullvadstatus()[1]):
            if new_ip and new_ip != last_ip and new_ip != previous:
                log_event("SUCCESS", f"Tunnel successfully rotated to {hl(redact_ip(new_ip))} ({hl(country)})")
                return new_ip
            elif new_ip and new_ip != previous:
                log_event("SUCCESS", f"Tunnel successfully established on {hl(redact_ip(new_ip))} ({hl(country)})")
                return new_ip
        last_ip = new_ip or last_ip
        if attempt < max_attempts:
            log_event("WARNING", "IP address unchanged; retrying rotation with alternate country node.")
    final_ip = get_public_ip()
    log_event("ERROR", f"Mullvad failed to rotate IP after {max_attempts} attempts (Last IP: {hl(redact_ip(final_ip))})")
    return last_ip if last_ip != previous else previous


async def rotate_mullvad_ip():
    if not MULLVADEXE:
        log_event("ERROR", "Mullvad CLI binary not found.")
        return False
    current_ip = get_public_ip()
    new_ip = await mullvad_cycle(old_ip=current_ip, max_attempts=5)
    return new_ip is not None and new_ip != current_ip

class MailboxClient:
    def __init__(self, api_token):
        self.email = None
        self.api_base = "https://api.cybertemp.xyz"
        self.token = api_token
        self.domain = None
        self.password = None

    async def get_domain(self):
        try:
            headers = {"X-API-KEY": self.token}
            params = {"type": "discord", "limit": 20}
            async with httpx.AsyncClient() as session:
                response = await session.get(f"{self.api_base}/getDomains", headers=headers, params=params)
                if response.status_code == 200:
                    data = response.json()
                    if data:
                        excluded = ["altmails.icu"]
                        filtered = [d for d in data if not d.endswith('.store') and not d.endswith('.ng') and d not in excluded]
                        if filtered:
                            return random.choice(filtered)
                        return random.choice([d for d in data if d not in excluded]) if any(d not in excluded for d in data) else "cybertemp.xyz"
        except:
            pass
        return "cybertemp.xyz"

    async def create_inbox(self):
        try:
            self.domain = await self.get_domain()
            user = ''.join(random.choices(string.ascii_lowercase + string.digits, k=random.randint(14, 18)))
            self.email = f"{user}@{self.domain}"
            self.password = create_random_string(12)
            return self.email
        except:
            pass
        return None

    async def get_verification_url(self):
        if not self.email:
            return None
        headers = {"X-API-KEY": self.token}
        params = {"email": self.email, "limit": 5}
        async with httpx.AsyncClient() as session:
            try:
                response = await session.get(f"{self.api_base}/getMail", headers=headers, params=params, timeout=15)
                if response.status_code == 200:
                    emails = response.json()
                    if isinstance(emails, list):
                        for mail in emails:
                            content = mail.get('html', '') or mail.get('text', '')
                            subj = mail.get('subject', '')
                            if "verify" in subj.lower() or "discord" in subj.lower():
                                patterns = [
                                    r'https?://click\.discord\.com/ls/click\?upn=[a-zA-Z0-9\-\._~%]+',
                                    r'https?://discord\.com/verify\?token=[a-zA-Z0-9\-\._~%]+'
                                ]
                                links = []
                                for pattern in patterns:
                                    matches = re.findall(pattern, content)
                                    for match in matches:
                                        url = match.replace('\\/', '/').split("\n")[0].strip()
                                        url = url.replace('&amp;', '&')
                                        if "click.discord.com/ls/click?upn=" in url or "discord.com/verify?token=" in url:
                                            if len(url) > 50:
                                                links.append(url)
                                if links:
                                    links.sort(key=len, reverse=True)
                                    return links[0]
            except Exception:
                pass
        return None


class Hotmail007Provider:
    def __init__(self, client_key, mail_type="hotmail"):
        self.client_key = client_key
        self.mail_type = mail_type
        self.email = None
        self.password = None
        self.refresh_token = None
        self.uuid = None
        self.base_api = "https://gapi.hotmail007.com/api"
        self.ms_client_id = "9e5f94bc-e8a4-4e73-b8be-63364c29d753"

    async def get_access_token(self, r_token=None, c_id=None):
        try:
            token = (r_token or self.refresh_token).rstrip("$")
            cid = c_id or self.uuid or self.ms_client_id
            url = "https://login.microsoftonline.com/common/oauth2/v2.0/token"
            data = {
                "client_id": cid,
                "refresh_token": token,
                "grant_type": "refresh_token",
                "scope": "https://graph.microsoft.com/.default"
            }
            async with httpx.AsyncClient() as client:
                r = await client.post(url, data=data, timeout=30)
                if r.status_code == 200:
                    return r.json().get("access_token")
        except:
            pass
        return None

    async def create_inbox(self):
        url = f"{self.base_api}/mail/getMail?clientKey={self.client_key}&mailType={self.mail_type}&quantity=1"
        try:
            async with httpx.AsyncClient() as client:
                r = await client.get(url, timeout=30)
                if r.status_code == 200:
                    data = r.json()
                    if data.get("code") == 0 and data.get("success"):
                        accounts = data.get("data", [])
                        if accounts:
                            parts = accounts[0].split(":")
                            if len(parts) >= 4:
                                self.email = parts[0].strip()
                                self.password = parts[1].strip()
                                self.refresh_token = parts[2].strip()
                                self.uuid = parts[3].strip()
                                return self.email
        except Exception:
            pass
        return None

    async def get_verification_url(self):
        if not self.refresh_token:
            return None
        access = await self.get_access_token()
        if not access:
            return None
        try:
            async with httpx.AsyncClient() as client:
                r = await client.get(
                    "https://graph.microsoft.com/v1.0/me/messages",
                    headers={"Authorization": f"Bearer {access}"},
                    params={"$top": 10, "$orderby": "receivedDateTime desc", "$select": "subject,body,from"},
                    timeout=15
                )
                if r.status_code == 200:
                    for msg in r.json().get("value", []):
                        subj = msg.get("subject", "").lower()
                        from_data = msg.get("from", {}).get("emailAddress", {})
                        frm_addr = from_data.get("address", "").lower()
                        frm_name = from_data.get("name", "").lower()
                        is_discord = "discord" in frm_addr or "discord" in frm_name
                        has_verify = "verify" in subj or "confirm" in subj or "verification" in subj
                        if is_discord and has_verify:
                            body = msg.get("body", {}).get("content", "")
                            body = body.replace("&amp;", "&").replace("&quot;", '"').replace("&#39;", "'")
                            matches = re.findall(r'https://discord\.com/verify\?token=[^\s"\'><]+', body)
                            if matches:
                                return matches[0]
                            tracked_links = re.findall(r'https://click\.discord\.com/ls/click\?[^\s"\'><]+', body)
                            for link in tracked_links:
                                try:
                                    async with httpx.AsyncClient() as check_client:
                                        res = await check_client.get(link, follow_redirects=False, timeout=10)
                                        target = res.headers.get("Location", "")
                                        if "discord.com/verify" in target:
                                            return link
                                except Exception:
                                    continue
        except Exception:
            pass
        return None


class ZeusXProvider:
    def __init__(self, api_key, account_code="HOTMAIL"):
        self.api_key = api_key
        self.account_code = account_code
        self.email = None
        self.password = None
        self.refresh_token = None
        self.uuid = None
        self.base_api = "https://api.zeus-x.ru"
        self.ms_client_id = "9e5f94bc-e8a4-4e73-b8be-63364c29d753"

    async def get_access_token(self, r_token=None, c_id=None):
        try:
            token = (r_token or self.refresh_token).rstrip("$")
            cid = c_id or self.uuid or self.ms_client_id
            url = "https://login.microsoftonline.com/common/oauth2/v2.0/token"
            data = {
                "client_id": cid,
                "refresh_token": token,
                "grant_type": "refresh_token",
                "scope": "https://graph.microsoft.com/.default"
            }
            async with httpx.AsyncClient() as client:
                r = await client.post(url, data=data, timeout=30)
                if r.status_code == 200:
                    return r.json().get("access_token")
        except:
            pass
        return None

    async def create_inbox(self):
        url = f"{self.base_api}/purchase?apikey={self.api_key}&accountcode={self.account_code}&quantity=1"
        try:
            async with httpx.AsyncClient() as client:
                r = await client.get(url, timeout=30)
                if r.status_code == 200:
                    data = r.json()
                    accounts = data.get("data", [])
                    if not accounts and isinstance(data, list):
                        accounts = data
                    if accounts:
                        parts = accounts[0].split(":")
                        if len(parts) >= 4:
                            self.email = parts[0].strip()
                            self.password = parts[1].strip()
                            self.refresh_token = parts[2].strip()
                            self.uuid = parts[3].strip()
                            return self.email
                        elif len(parts) >= 3:
                            self.email = parts[0].strip()
                            self.password = parts[1].strip()
                            self.refresh_token = parts[2].strip()
                            return self.email
        except Exception:
            pass
        return None

    async def get_verification_url(self):
        if not self.refresh_token:
            return None
        access = await self.get_access_token()
        if not access:
            return None
        try:
            async with httpx.AsyncClient() as client:
                r = await client.get(
                    "https://graph.microsoft.com/v1.0/me/messages",
                    headers={"Authorization": f"Bearer {access}"},
                    params={"$top": 10, "$orderby": "receivedDateTime desc", "$select": "subject,body,from"},
                    timeout=15
                )
                if r.status_code == 200:
                    for msg in r.json().get("value", []):
                        subj = msg.get("subject", "").lower()
                        from_data = msg.get("from", {}).get("emailAddress", {})
                        frm_addr = from_data.get("address", "").lower()
                        frm_name = from_data.get("name", "").lower()
                        is_discord = "discord" in frm_addr or "discord" in frm_name
                        has_verify = "verify" in subj or "confirm" in subj or "verification" in subj
                        if is_discord and has_verify:
                            body = msg.get("body", {}).get("content", "")
                            body = body.replace("&amp;", "&").replace("&quot;", '"').replace("&#39;", "'")
                            matches = re.findall(r'https://discord\.com/verify\?token=[^\s"\'><]+', body)
                            if matches:
                                return matches[0]
                            tracked_links = re.findall(r'https://click\.discord\.com/ls/click\?[^\s"\'><]+', body)
                            for link in tracked_links:
                                try:
                                    async with httpx.AsyncClient() as check_client:
                                        res = await check_client.get(link, follow_redirects=False, timeout=10)
                                        target = res.headers.get("Location", "")
                                        if "discord.com/verify" in target:
                                            return link
                                except Exception:
                                    continue
        except Exception:
            pass
        return None

class DuckMailProvider:
    def __init__(self, api_key=None, never_expire=False):
        self.email = None
        self.password = None
        self.api_base = "https://api.duckmail.sbs"
        self.api_key = api_key
        self.auth_token = None
        self.account_id = None
        self.never_expire = never_expire

    def get_domains(self):
        try:
            headers = {}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"
            response = requests.get(f"{self.api_base}/domains", headers=headers, timeout=15, impersonate="chrome124")
            if response.status_code == 200:
                data = response.json()
                members = data.get("hydra:member", [])
                valid_domains = []
                for item in members:
                    domain = item.get("domain")
                    if domain and item.get("isVerified") and not is_domain_blacklisted(domain):
                        valid_domains.append(domain)
                if valid_domains:
                    return valid_domains
        except:
            pass
        return None

    async def create_inbox(self, session=None):
        try:
            domains = self.get_domains()
            if not domains:
                return None
            domain = random.choice(domains)
            user = "".join(random.choices(string.ascii_lowercase + string.digits, k=random.randint(10, 16)))
            self.email = f"{user}@{domain}"
            self.password = create_random_string(12)

            headers = {"Content-Type": "application/json"}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"
            payload = {
                "address": self.email,
                "password": self.password,
                "expiresIn": 0 if self.never_expire else 86400,
            }
            create_resp = requests.post(f"{self.api_base}/accounts", headers=headers, json=payload, timeout=15, impersonate="chrome124")
            if create_resp.status_code not in [200, 201]:
                return None

            token_payload = {"address": self.email, "password": self.password}
            token_resp = requests.post(f"{self.api_base}/token", headers={"Content-Type": "application/json"}, json=token_payload, timeout=15, impersonate="chrome124")
            if token_resp.status_code == 200:
                token_data = token_resp.json()
                self.auth_token = token_data.get("token")
                self.account_id = token_data.get("id")
            return self.email
        except:
            pass
        return None

    async def get_verification_url(self):
        if not self.auth_token:
            return None
        headers = {"Authorization": f"Bearer {self.auth_token}"}
        try:
            for _ in range(3):
                response = requests.get(f"{self.api_base}/messages", headers=headers, timeout=15, impersonate="chrome124")
                if response.status_code == 200:
                    data = response.json()
                    messages = data.get("hydra:member", [])
                    if isinstance(messages, list):
                        for mail in messages:
                            subject = str(mail.get("subject", "") or "").lower()
                            from_data = mail.get("from", {}) or {}
                            from_address = str(from_data.get("address", "") or "").lower()
                            from_name = str(from_data.get("name", "") or "").lower()
                            is_discord = "discord" in from_address or "discord" in from_name
                            has_verify = "verify" in subject or "confirm" in subject or "verification" in subject
                            if is_discord or has_verify:
                                msg_id = mail.get("id")
                                if msg_id:
                                    detail_resp = requests.get(f"{self.api_base}/messages/{msg_id}", headers=headers, timeout=15, impersonate="chrome124")
                                    if detail_resp.status_code == 200:
                                        msg_detail = detail_resp.json()
                                        content_parts = []
                                        text_body = str(msg_detail.get("text", "") or "")
                                        if text_body:
                                            content_parts.append(text_body)
                                        html_bodies = msg_detail.get("html", []) or []
                                        for html_body in html_bodies:
                                            content_parts.append(str(html_body or ""))
                                        full_content = "\n".join(content_parts)
                                        patterns = [
                                            r'https?://(?:www\.)?discord\.com/verify\?token=[a-zA-Z0-9\-\._~%]+',
                                            r'https?://click\.discord\.com/ls/click\?upn=[a-zA-Z0-9\-\._~%]+',
                                        ]
                                        found_links = []
                                        for pattern in patterns:
                                            matches = re.findall(pattern, full_content, re.IGNORECASE)
                                            for url in matches:
                                                url = url.replace("\\/", "/").split("\n")[0].strip().replace("&amp;", "&")
                                                url = re.sub(r"[.,;>]$", "", url)
                                                if len(url) > 50:
                                                    found_links.append(url)
                                        if found_links:
                                            verify_links = [link for link in found_links if "discord.com/verify" in link]
                                            if verify_links:
                                                verify_links.sort(key=len, reverse=True)
                                                return verify_links[0]
                                            found_links.sort(key=len, reverse=True)
                                            return found_links[0]
                await asyncio.sleep(1)
        except:
            pass
        return None


class CrowMailProvider:
    def __init__(self, api_key=None, never_expire=False):
        self.email = None
        self.password = None
        self.api_base = "https://api.crowmail.sbs"
        self.api_key = api_key
        self.auth_token = None
        self.account_id = None
        self.never_expire = never_expire

    def get_domains(self):
        try:
            headers = {}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"
            response = requests.get(f"{self.api_base}/domains", headers=headers, timeout=15, impersonate="chrome124")
            if response.status_code == 200:
                data = response.json()
                members = data.get("hydra:member", [])
                valid_domains = []
                for item in members:
                    domain = item.get("domain")
                    if domain and item.get("isVerified") and not is_domain_blacklisted(domain):
                        valid_domains.append(domain)
                if valid_domains:
                    return valid_domains
        except:
            pass
        return None

    async def create_inbox(self, session=None):
        try:
            domains = self.get_domains()
            if not domains:
                return None
            domain = random.choice(domains)
            user = "".join(random.choices(string.ascii_lowercase + string.digits, k=random.randint(10, 16)))
            self.email = f"{user}@{domain}"
            self.password = create_random_string(12)

            headers = {"Content-Type": "application/json"}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"
            payload = {
                "address": self.email,
                "password": self.password,
                "expiresIn": 0 if self.never_expire else 86400,
            }
            create_resp = requests.post(f"{self.api_base}/accounts", headers=headers, json=payload, timeout=15, impersonate="chrome124")
            if create_resp.status_code not in [200, 201]:
                return None

            token_payload = {"address": self.email, "password": self.password}
            token_resp = requests.post(f"{self.api_base}/token", headers={"Content-Type": "application/json"}, json=token_payload, timeout=15, impersonate="chrome124")
            if token_resp.status_code == 200:
                token_data = token_resp.json()
                self.auth_token = token_data.get("token")
                self.account_id = token_data.get("id")
            return self.email
        except:
            pass
        return None

    async def get_verification_url(self):
        if not self.auth_token:
            return None
        headers = {"Authorization": f"Bearer {self.auth_token}"}
        try:
            for _ in range(3):
                response = requests.get(f"{self.api_base}/messages", headers=headers, timeout=15, impersonate="chrome124")
                if response.status_code == 200:
                    data = response.json()
                    messages = data.get("hydra:member", [])
                    if isinstance(messages, list):
                        for mail in messages:
                            subject = str(mail.get("subject", "") or "").lower()
                            from_data = mail.get("from", {}) or {}
                            from_address = str(from_data.get("address", "") or "").lower()
                            from_name = str(from_data.get("name", "") or "").lower()
                            is_discord = "discord" in from_address or "discord" in from_name
                            has_verify = "verify" in subject or "confirm" in subject or "verification" in subject
                            if is_discord or has_verify:
                                msg_id = mail.get("id")
                                if msg_id:
                                    detail_resp = requests.get(f"{self.api_base}/messages/{msg_id}", headers=headers, timeout=15, impersonate="chrome124")
                                    if detail_resp.status_code == 200:
                                        msg_detail = detail_resp.json()
                                        content_parts = []
                                        text_body = str(msg_detail.get("text", "") or "")
                                        if text_body:
                                            content_parts.append(text_body)
                                        html_bodies = msg_detail.get("html", []) or []
                                        for html_body in html_bodies:
                                            content_parts.append(str(html_body or ""))
                                        full_content = "\n".join(content_parts)
                                        patterns = [
                                            r'https?://(?:www\.)?discord\.com/verify\?token=[a-zA-Z0-9\-\._~%]+',
                                            r'https?://click\.discord\.com/ls/click\?upn=[a-zA-Z0-9\-\._~%]+',
                                        ]
                                        found_links = []
                                        for pattern in patterns:
                                            matches = re.findall(pattern, full_content, re.IGNORECASE)
                                            for url in matches:
                                                url = url.replace("\\/", "/").split("\n")[0].strip().replace("&amp;", "&")
                                                url = re.sub(r"[.,;>]$", "", url)
                                                if len(url) > 50:
                                                    found_links.append(url)
                                        if found_links:
                                            verify_links = [link for link in found_links if "discord.com/verify" in link]
                                            if verify_links:
                                                verify_links.sort(key=len, reverse=True)
                                                return verify_links[0]
                                            found_links.sort(key=len, reverse=True)
                                            return found_links[0]
                await asyncio.sleep(1)
        except:
            pass
        return None


class AfhamMailProvider:
    def __init__(self, api_key="axm_moOcVCBUD6r1FbIeThT0wEmEofjuaDnJdMiQj7OymTU"):
        self.api_key = api_key
        self.api_base = "https://api.afhamxmailz.com"
        self.email = None
        self.inbox_id = None
        self.password = None

    def _headers(self):
        return {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
        }

    async def get_discord_domain(self):
        try:
            async with httpx.AsyncClient() as session:
                response = await session.get(
                    f"{self.api_base}/domains",
                    headers=self._headers(),
                    params={"type": "discord"},
                    timeout=15,
                )
                if response.status_code == 200:
                    data = response.json()
                    if isinstance(data, list):
                        valid = [
                            d["domain"] for d in data
                            if isinstance(d, dict)
                            and d.get("status") == "active"
                            and not d.get("domain", "").endswith(".store")
                            and not d.get("domain", "").endswith(".ng")
                        ]
                        if valid:
                            return random.choice(valid)
        except:
            pass
        return None

    async def create_inbox(self):
        try:
            domain = await self.get_discord_domain()
            if not domain:
                return None

            user = "".join(random.choices(string.ascii_lowercase + string.digits, k=random.randint(10, 16)))
            self.password = create_random_string(12)
            payload = {
                "username": user,
                "domain": domain,
                "password": self.password,
            }
            async with httpx.AsyncClient() as session:
                response = await session.post(
                    f"{self.api_base}/inbox/generate",
                    headers=self._headers(),
                    json=payload,
                    params={"type": "discord"},
                    timeout=15,
                )
                if response.status_code in [200, 201]:
                    data = response.json()
                    self.email = data.get("address")
                    self.inbox_id = data.get("id")
                    return self.email
        except:
            pass
        return None

    async def get_verification_url(self):
        if not self.email:
            return None
        try:
            async with httpx.AsyncClient() as session:
                response = await session.get(
                    f"{self.api_base}/emails/{self.email}/wait",
                    headers=self._headers(),
                    params={"timeout": 30},
                    timeout=40,
                )
                emails = []
                if response.status_code == 200:
                    data = response.json()
                    if isinstance(data, list):
                        emails = data

                if not emails:
                    response = await session.get(
                        f"{self.api_base}/emails/{self.email}",
                        headers=self._headers(),
                        params={"per_page": 20, "unread_only": False},
                        timeout=15,
                    )
                    if response.status_code == 200:
                        data = response.json()
                        emails = data.get("emails", []) if isinstance(data, dict) else data

                for mail in emails:
                    subject = str(mail.get("subject", "") or "").lower()
                    from_address = str(mail.get("from_address", "") or "").lower()
                    from_name = str(mail.get("from_name", "") or "").lower()
                    is_discord = "discord" in from_address or "discord" in from_name
                    has_verify = "verify" in subject or "confirm" in subject or "verification" in subject
                    if not (is_discord or has_verify):
                        continue

                    msg_id = mail.get("id")
                    if not msg_id:
                        continue

                    detail_resp = await session.get(
                        f"{self.api_base}/emails/message/{msg_id}",
                        headers=self._headers(),
                        timeout=15,
                    )
                    if detail_resp.status_code != 200:
                        continue

                    msg = detail_resp.json()
                    full_content = (
                        str(msg.get("body_text", "") or "") + "\n" +
                        str(msg.get("body_html", "") or "")
                    ).replace("&amp;", "&")

                    patterns = [
                        r'https?://(?:www\.)?discord\.com/verify\?token=[a-zA-Z0-9\-\._~%]+',
                        r'https?://click\.discord\.com/ls/click\?upn=[a-zA-Z0-9\-\._~%]+',
                    ]
                    links = []
                    for pattern in patterns:
                        for url in re.findall(pattern, full_content, re.IGNORECASE):
                            url = url.replace("\\/", "/").split("\n")[0].strip()
                            url = re.sub(r"[.,;>]$", "", url)
                            if len(url) > 50:
                                links.append(url)

                    if links:
                        verify_links = [l for l in links if "discord.com/verify" in l]
                        if verify_links:
                            verify_links.sort(key=len, reverse=True)
                            return verify_links[0]
                        links.sort(key=len, reverse=True)
                        return links[0]
        except:
            pass
        return None

def check_environment():
    if get_brave_path():
        return True
    return False


class BrowserContext:
    def __init__(self):
        self.driver = None

    async def start(self, url, extension_path=None, proxy=None):
        brave_path = get_brave_path()
        if not brave_path:
            log_event("ERROR", "Brave browser binary could not be located.")
            return None
        
        args = ["--lang=en-US"]
        if extension_path:
            args.append(f"--load-extension={extension_path}")
            args.append(f"--disable-extensions-except={extension_path}")

        try:
            self.driver = await uc.start(
                browser_executable_path=brave_path,
                browser_args=args,
                proxy=proxy
            )
            tab = await self.driver.get(url)
            await tab.wait_for_ready_state('complete', timeout=30000)
            try:
                await tab.evaluate(JS_UTILS)
            except:
                pass
            return tab
        except Exception as e:
            log_event("ERROR", f"Browser instance startup failed: {str(e)}")
            return None

    async def stop(self):
        if self.driver:
            try:
                await self.driver.stop()
            except:
                pass
            finally:
                self.driver = None


class AccountCreator:
    def __init__(self, api_key, mailbox_class, extension_path=None, proxy=None, custom_display_name=None):
        self.extension_path = extension_path
        self.proxy = proxy
        self.custom_display_name = custom_display_name
        self.mailbox = mailbox_class(api_key)
        self.browser = BrowserContext()
        self.password = None
        self.email = None
        self.token = None
        self.session = tls_client.Session(
            client_identifier="chrome_131",
            random_tls_extension_order=True
        )
        if proxy:
            self.session.proxies = {"http": proxy, "https": proxy}

    def save_account_locally(self, status, token=""):
        output_dir = Path(get_path("output"))
        output_dir.mkdir(exist_ok=True)
        if status == "valid" and token:
            acc_path = output_dir / "accounts.txt"
            tok_path = output_dir / "tokens.txt"
            with open(acc_path, "a", encoding="utf-8") as f:
                f.write(f"{self.email}:{self.password}:{token}\n")
            with open(tok_path, "a", encoding="utf-8") as f:
                f.write(f"{token}\n")
        elif status == "locked" and token:
            locked_path = output_dir / "locked.txt"
            with open(locked_path, "a", encoding="utf-8") as f:
                f.write(f"{self.email}:{self.password}:{token}\n")

    async def report_status(self, status, token=""):
        self.save_account_locally(status, token)

    async def run(self):
        start_time = time.time()
        try:
            addr = await self.mailbox.create_inbox()
            if not addr:
                log_event("ERROR", "Mailbox generation failed.")
                return None
            self.email = addr
            log_event("SUCCESS", f"Inbox acquired: {hl(addr)}")

            nopecha_key = get_current_nopecha_key()
            if nopecha_key:
                nopecha_setup_url = f"https://nopecha.com/setup#{nopecha_key}"
                nopecha_page = await self.browser.start(nopecha_setup_url, extension_path=self.extension_path, proxy=self.proxy)
                if nopecha_page:
                    await asyncio.sleep(1)
                    page = await self.browser.driver.get("https://discord.com/register")
                    await page.wait_for_ready_state('complete', timeout=30000)
                    try:
                        await page.evaluate(JS_UTILS)
                    except:
                        pass
                else:
                    page = await self.browser.start("https://discord.com/register", extension_path=self.extension_path, proxy=self.proxy)
            else:
                page = await self.browser.start("https://discord.com/register", extension_path=self.extension_path, proxy=self.proxy)
                
            if not page:
                log_event("ERROR", "Browser initialization failed.")
                return None

            try:
                first_names = ["James", "Mary", "Robert", "Patricia", "John", "Jennifer", "Michael", "Linda", "William", "Elizabeth", "David", "Barbara", "Richard", "Susan", "Joseph", "Jessica", "Thomas", "Sarah", "Charles", "Karen"]
                last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez"]
                display_name = self.custom_display_name or f"{random.choice(first_names)} {random.choice(last_names)}"
                user_name = make_handle()
                secret = self.mailbox.password or create_random_string(14)
                self.password = secret

                success = await self.fill_registration_form(page, addr, display_name, user_name, secret)
                if not success:
                    log_event("ERROR", "Registration form submission failed.")
                    return None, 0

                await self.handle_challenges(page)

                result = await self.verify_email()
                if result:
                    end_time = time.time()
                    return result, end_time - start_time
                else:
                    log_event("ERROR", "Email verification failed.")
                    return None, 0
            except Exception as e:
                log_event("ERROR", f"Execution error: {str(e)}")
                return None, 0
            finally:
                await self.browser.stop()
        except Exception as e:
            log_event("ERROR", f"Fatal process error: {str(e)}")
            return None, 0

    async def human_type(self, element, text: str):
        for char in text:
            await element.send_keys(char)
            await asyncio.sleep(random.uniform(0.005, 0.02))

    async def clear_and_type(self, page, selector: str, value: str, timeout: int = 45):
        try:
            element = None
            for _ in range(5):
                try:
                    element = await page.select(selector, timeout=timeout//5)
                    if element: break
                except:
                    await asyncio.sleep(2)
            if not element:
                raise Exception(f"Element selector not found: {selector}")
            selector_js = json.dumps(selector)
            await page.evaluate(
                f'''() => {{
                    const el = document.querySelector({selector_js});
                    if (!el) return;
                    el.focus();
                    el.value = "";
                    el.dispatchEvent(new Event("input", {{ bubbles: true }}));
                    el.dispatchEvent(new Event("change", {{ bubbles: true }}));
                }}'''
            )
            await asyncio.sleep(random.uniform(0.01, 0.04))
            await self.human_type(element, value)
        except Exception as e:
            raise e

    async def fill_registration_form(self, page, email: str, display_name: str, username: str, password: str) -> bool:
        try:
            try:
                await self.clear_and_type(page, 'input[name="email"]', email, timeout=45)
                await asyncio.sleep(random.uniform(0.05, 0.15))
            except Exception as e:
                return False
            try:
                await self.clear_and_type(page, 'input[name="global_name"]', display_name, timeout=20)
                await asyncio.sleep(random.uniform(0.05, 0.15))
            except Exception as e:
                return False
            try:
                await self.clear_and_type(page, 'input[name="username"]', username, timeout=20)
                await asyncio.sleep(random.uniform(0.05, 0.15))
            except Exception as e:
                return False
            try:
                await self.clear_and_type(page, 'input[name="password"]', password, timeout=20)
                await asyncio.sleep(random.uniform(0.05, 0.15))
            except Exception as e:
                return False
            await asyncio.sleep(0.1)
            await self.fill_date_of_birth(page)
            await asyncio.sleep(0.05)
            try:
                await page.evaluate(JS_UTILS)
                await asyncio.sleep(0.05)
                await page.evaluate('window.utils.clickAllCheckboxes()')
                await asyncio.sleep(0.05)
            except Exception as e:
                pass
            clicked = False
            await asyncio.sleep(0.1)
            try:
                buttons = await page.select_all('button')
                for button in buttons:
                    try:
                        text = (await button.get_text() or "").strip()
                        if not text: text = (button.text or "").strip()
                        if text and any(keyword in text for keyword in ['Continue', 'Create', 'Submit', 'Register']):
                            await button.click()
                            clicked = True
                            break
                    except: continue
            except: pass
            if not clicked:
                try:
                    submit = await page.select('[type="submit"]', timeout=0)
                    if submit:
                        await submit.click()
                        clicked = True
                except: pass
            if not clicked:
                try:
                    clicked_eval = await page.evaluate('''() => { 
                        const buttons = document.querySelectorAll('button'); 
                        for (const btn of buttons) { 
                            const text = btn.textContent || ''; 
                            if (text.includes('Continue') || text.includes('Create') || text.includes('Submit')) { 
                                btn.click(); 
                                return true; 
                            } 
                        } 
                        return false; 
                    }''')
                    if clicked_eval: clicked = True
                except Exception as e: pass
            if not clicked: return False
            return True
        except Exception as e: 
            return False

    async def fill_date_of_birth(self, page):
        import truedriver.cdp.input_ as cdp_input
        try:
            month_el = await page.select('[aria-label*="Month"], [aria-label*="Mês"]', timeout=5)
            await month_el.click()
            await asyncio.sleep(0.05)
            month_scrolls = random.randint(1, 11)
            for _ in range(month_scrolls):
                await page.send(cdp_input.dispatch_key_event(type_="keyDown", key="ArrowDown", windows_virtual_key_code=40, native_virtual_key_code=40))
                await page.send(cdp_input.dispatch_key_event(type_="keyUp", key="ArrowDown", windows_virtual_key_code=40, native_virtual_key_code=40))
                await asyncio.sleep(0.005)
            await asyncio.sleep(0.05)
            await page.send(cdp_input.dispatch_key_event(type_="keyDown", key="Enter", windows_virtual_key_code=13, native_virtual_key_code=13))
            await page.send(cdp_input.dispatch_key_event(type_="keyUp", key="Enter", windows_virtual_key_code=13, native_virtual_key_code=13))
            await asyncio.sleep(0.05)
            day_el = await page.select('[aria-label*="Day"], [aria-label*="Dia"]', timeout=5)
            await day_el.click()
            await asyncio.sleep(0.05)
            day_scrolls = random.randint(1, 28)
            for _ in range(day_scrolls):
                await page.send(cdp_input.dispatch_key_event(type_="keyDown", key="ArrowDown", windows_virtual_key_code=40, native_virtual_key_code=40))
                await page.send(cdp_input.dispatch_key_event(type_="keyUp", key="ArrowDown", windows_virtual_key_code=40, native_virtual_key_code=40))
                await asyncio.sleep(0.005)
            await asyncio.sleep(0.05)
            await page.send(cdp_input.dispatch_key_event(type_="keyDown", key="Enter", windows_virtual_key_code=13, native_virtual_key_code=13))
            await page.send(cdp_input.dispatch_key_event(type_="keyUp", key="Enter", windows_virtual_key_code=13, native_virtual_key_code=13))
            await asyncio.sleep(0.05)
            year_el = await page.select('[aria-label*="Year"], [aria-label*="Ano"]', timeout=5)
            await year_el.click()
            await asyncio.sleep(0.05)
            year_scrolls = random.randint(25, 35)
            for _ in range(year_scrolls):
                await page.send(cdp_input.dispatch_key_event(type_="keyDown", key="ArrowDown", windows_virtual_key_code=40, native_virtual_key_code=40))
                await page.send(cdp_input.dispatch_key_event(type_="keyUp", key="ArrowDown", windows_virtual_key_code=40, native_virtual_key_code=40))
                await asyncio.sleep(0.005)
            await asyncio.sleep(0.05)
            await page.send(cdp_input.dispatch_key_event(type_="keyDown", key="Enter", windows_virtual_key_code=13, native_virtual_key_code=13))
            await page.send(cdp_input.dispatch_key_event(type_="keyUp", key="Enter", windows_virtual_key_code=13, native_virtual_key_code=13))
        except Exception as e:
            pass

    async def handle_challenges(self, page):
        try:
            is_active = False
            for i in range(120):
                queries = ['iframe[src*="captcha"]', 'div[class*="captcha"]', '.h-captcha', '.g-recaptcha', '[data-sitekey]']
                detected = False
                for q in queries:
                    try:
                        el = await page.query_selector(q)
                        if el and await el.is_visible():
                            detected = True
                            break
                    except:
                        continue
                
                if detected and not is_active:
                    log_event("WARNING", "CAPTCHA challenge detected on interface.")
                    is_active = True
                
                if not detected:
                    if is_active:
                        log_event("SUCCESS", "CAPTCHA challenge successfully resolved.")
                        return True
                    elif i >= 10:
                        return True
                
                await asyncio.sleep(0.5)
        except Exception as e:
            pass
        return True

    async def get_generated_token(self, page):
        script = """
        (function() {
            try {
                const chunks = window.webpackChunkdiscord_app;
                let store;
                chunks.push([['__extra_extract__'], {}, (e) => { store = Object.values(e.c); }]);
                const mod = store.find(m => m?.exports?.default?.getToken !== undefined);
                const auth = mod.exports.default.getToken();
                if (auth) return auth;
            } catch (e) {}
            try {
                const node = document.createElement('iframe');
                document.body.appendChild(node);
                const auth = node.contentWindow.localStorage.token;
                document.body.removeChild(node);
                if (auth) return auth.replace(/\"/g, "");
            } catch (e) {}
            return null;
        })();
        """
        try:
            return await page.evaluate(script)
        except:
            return None

    async def wait_for_auth(self, page):
        while True:
            token = await self.get_generated_token(page)
            if token and len(str(token)) > 30:
                valid, _ = self.validate_token(token)
                if valid:
                    return token
            await asyncio.sleep(5)

    def validate_token(self, token):
        if not isinstance(token, str) or not token:
            return None, None
        
        endpoint = "https://discord.com/api/v9/users/@me"
        headers = get_headers()
        headers["Authorization"] = token
        try:
            resp = self.session.get(endpoint, headers=headers)
            if resp.status_code == 200:
                info = resp.json()
                return info.get("verified", False), info.get("email", "")
            return None, None
        except:
            return None, None

    def is_flagged(self, token):
        if not isinstance(token, str) or not token:
            return None
        
        endpoint = "https://discordapp.com/api/v9/users/@me/library"
        headers = get_headers()
        headers["Authorization"] = token
        try:
            resp = self.session.get(endpoint, headers=headers)
            return resp.status_code
        except:
            return None

    async def verify_email(self):
        url = None
        for _ in range(300):
            try:
                url = await self.mailbox.get_verification_url()
                if url: break
            except: pass
            await asyncio.sleep(1)
        
        if not url:
            log_event("ERROR", "Verification email retrieval timeout reached.")
            return None

        try:
            if not self.browser.driver:
                return None
            
            tab = await self.browser.driver.get(url, new_tab=True)
            
            challenge_task = asyncio.create_task(self.handle_challenges(tab))
            token = await self.wait_for_auth(tab)
            challenge_task.cancel()
            if not token:
                log_event("ERROR", "Token extraction failed from browser context.")
                return None

            log_event("INFO", "Verifying token validity...")

            if self.is_flagged(token) == 403:
                mask = f"{token[:24]}{'*' * 12}"
                ts = datetime.now().strftime("%H:%M:%S")
                print(f"{Fore.LIGHTBLACK_EX}[{ts}]{Style.RESET_ALL} {Style.BRIGHT}{Fore.YELLOW}[ WARNING ]{Style.RESET_ALL} {Fore.WHITE}Account locked: {Style.RESET_ALL}{hl_token(mask)}")
                with open("output/locked.txt", "a", encoding="utf-8") as f:
                    f.write(f"{self.email}:{self.password}:{token}\n")
                return "LOCKED"

            log_event("SUCCESS", "Account verified successfully.")
            log_token(f"{token[:24]}{'*' * 12}")
            self.save_data(token)
            return token
        except Exception as e:
            log_event("ERROR", f"Verification exception: {str(e)}")
            return None

    def save_data(self, token):
        try:
            os.makedirs("output", exist_ok=True)
            with open("output/tokens.txt", "a", encoding="utf-8") as f:
                f.write(token + "\n")
            with open("output/accounts.txt", "a", encoding="utf-8") as f:
                f.write(f"{self.email}:{self.password}:{token}\n")
            self.token = token
        except:
            pass

def setup_files():
    folders = ["config", "extension", "output", "data", "data/avatars", "input"]
    for folder in folders:
        Path(get_path(folder)).mkdir(exist_ok=True, parents=True)
    
    config_path = Path(get_path("config/config.yaml"))
    if not config_path.exists():
        with open(config_path, "w") as f:
            yaml.dump({"cybertemp_key": "", "hotmail007_key": "", "zeusx_key": "", "afham_mail_api9_key": "", "vpn": False, "vpn_delay": 120}, f)
    
    nopecha_path = Path(get_path("config/nopecha.txt"))
    if not nopecha_path.exists():
        nopecha_path.write_text("")


def load_humanizer_data():
    data_dir = Path(get_path("data"))
    names = []
    bios = []
    pronouns = []
    avatar_files = []
    
    names_file = data_dir / "names.txt"
    if names_file.exists():
        with open(names_file, 'r', encoding='utf-8') as f:
            names = [line.strip() for line in f if line.strip() and not line.startswith('#')]

    bio_file = data_dir / "bio.txt"
    if bio_file.exists():
        with open(bio_file, 'r', encoding='utf-8') as f:
            bios = [line.strip() for line in f if line.strip() and not line.startswith('#')]

    pronoun_file = data_dir / "pronoun.txt"
    if pronoun_file.exists():
        with open(pronoun_file, 'r', encoding='utf-8') as f:
            pronouns = [line.strip() for line in f if line.strip() and not line.startswith('#')]

    avatars_dir = data_dir / "avatars"
    if avatars_dir.exists():
        valid_ext = {'.gif', '.png', '.webp', '.jpeg', '.jpg'}
        avatar_files = [f for f in avatars_dir.iterdir() if f.suffix.lower() in valid_ext]
    
    return names, bios, pronouns, avatar_files


def load_avatar_as_base64(image_path: Path, dimension=256):
    try:
        with Image.open(image_path) as img:
            is_png = image_path.suffix.lower() == '.png'
            if is_png:
                if img.mode == 'P':
                    img = img.convert('RGBA')
            else:
                if img.mode in ['RGBA', 'P']:
                    img = img.convert('RGB')
            img = img.resize((dimension, dimension), Image.Resampling.LANCZOS)
            img_copy = img.copy()

        def _encode(pil_img, fmt, quality=80):
            buf = io.BytesIO()
            kw = {'format': fmt}
            if fmt == 'JPEG':
                kw['quality'] = quality
                kw['optimize'] = True
            pil_img.save(buf, **kw)
            buf.seek(0)
            return base64.b64encode(buf.read()).decode()

        img_format = 'PNG' if is_png else 'JPEG'
        b64 = _encode(img_copy, img_format)
        mime = 'image/png' if img_format == 'PNG' else 'image/jpeg'

        if len(b64) > 1_000_000:
            work = img_copy.convert('RGB') if img_copy.mode in ['RGBA', 'P', 'LA'] else img_copy
            mime = 'image/jpeg'
            for q in [80, 60, 40, 20]:
                b64 = _encode(work, 'JPEG', q)
                if len(b64) <= 1_000_000:
                    return f'data:{mime};base64,{b64}'
            return None

        return f'data:{mime};base64,{b64}'
    except Exception:
        return None


def humanize_token(token, names, bios, pronouns, avatar_files, custom_display_name=None):
    try:
        import humanizer as _hz

        h = _hz.Humanizer(token)
        headers = h.get_headers()

        display_name = custom_display_name if custom_display_name else (random.choice(names) if names else None)
        bio = random.choice(bios) if bios else None
        pronoun = random.choice(pronouns) if pronouns else None

        account_payload = {}
        if display_name:
            account_payload['global_name'] = display_name

        if avatar_files:
            try:
                ap = random.choice(avatar_files)
                ab64 = load_avatar_as_base64(ap)
                if ab64:
                    account_payload['avatar'] = ab64
                    import hashlib
                    from datetime import datetime as _dt
                    av_hash = hashlib.md5(ab64[:100].encode()).hexdigest()
                    now = _dt.now()
                    account_payload['avatar_description'] = av_hash + ', added ' + now.strftime("%B {d}, %Y at {t}").format(d=now.day, t=now.strftime("%I:%M %p").lstrip("0"))
            except Exception as ex:
                log_event("WARNING", f"Humanize avatar preparation error: {str(ex)[:60]}")

        if account_payload:
            try:
                if 'avatar' in account_payload:
                    r = h.update_account_sync(account_payload)
                else:
                    r = h.update_user_profile(account_payload, headers)
                if r.get('success'):
                    if display_name:
                        log_event("SUCCESS", f"Humanized display name set to: {hl(display_name)}")
                    if 'avatar' in account_payload:
                        log_event("SUCCESS", "Humanized avatar profile image applied.")
                elif r.get('captcha'):
                    log_event("WARNING", "Humanize profile operation restricted by CAPTCHA.")
                elif r.get('rate_limited'):
                    log_event("WARNING", "Humanize profile operation rate limited.")
                else:
                    err = str(r.get('error', 'unknown'))[:80]
                    log_event("WARNING", f"Humanize profile request failed: {err}")
            except Exception as ex:
                log_event("WARNING", f"Humanize profile exception: {str(ex)[:80]}")

        profile_payload = {}
        if bio:
            profile_payload['bio'] = bio
        if pronoun:
            profile_payload['pronouns'] = pronoun

        if profile_payload:
            try:
                r = h.update_profile_fields(profile_payload, headers)
                if r.get('success'):
                    if bio:
                        log_event("SUCCESS", "Humanized biography applied.")
                    if pronoun:
                        log_event("SUCCESS", f"Humanized pronouns applied: {hl(pronoun)}")
                else:
                    err = str(r.get('error', 'unknown'))[:80]
                    log_event("WARNING", f"Humanize profile fields request failed: {err}")
            except Exception as ex:
                log_event("WARNING", f"Humanize profile fields exception: {str(ex)[:80]}")

        try:
            import time as _t
            _t.sleep(random.uniform(1, 3))
            hi = random.choice([1, 2, 3])
            r = h.set_hypesquad(hi, headers)
            if r.get('success'):
                hname = r.get('house_name', _hz.HYPESQUAD_HOUSES.get(hi, 'Unknown'))
                tag = "already" if r.get('already_set') else "set"
                log_event("SUCCESS", f"Hypesquad house {tag}: {hl(hname)}")
            else:
                err = str(r.get('error', 'unknown'))[:60]
                log_event("WARNING", f"Hypesquad assignment failed: {err}")
        except Exception as ex:
            log_event("WARNING", f"Hypesquad assignment exception: {str(ex)[:60]}")

        return True
    except ImportError as e:
        log_event("WARNING", f"Humanizer module import failure: {str(e)}")
        return False
    except Exception as e:
        log_event("WARNING", f"Humanizer execution exception: {str(e)[:100]}")
        return False

async def main():
    clear_screen()
    set_console_title()
    setup_files()
    
    try:
        config_path = get_path("config/config.yaml")
        if not os.path.exists(config_path):
            log_event("ERROR", f"Configuration file not found at: {config_path}")
            prompt_user("Press Enter to exit...")
            return

        with open(config_path, "r") as f:
            cfg = yaml.safe_load(f)
            use_vpn = cfg.get('vpn', False)
            vpn_delay = int(cfg.get('vpn_delay', 120))
    except Exception as e:
        log_event("ERROR", f"Configuration parsing error: {e}")
        prompt_user("Press Enter to exit...")
        return

    if use_vpn:
        await mullvad_ensure_connected()

    if not check_environment():
        log_event("WARNING", "Brave browser environment not detected in standard paths.")

    names, bios, pronouns, avatar_files = load_humanizer_data()

    show_interface()
    
    service = prompt_user("Select mail provider - Cybertemp (C), Hotmail (H), Zeus-X (Z), Afham (A), DuckMail (D) or CrowMail (R): ").strip().lower()
    if service == 'h':
        key = cfg.get('hotmail007_key')
        mailbox_class = Hotmail007Provider
    elif service == 'z':
        key = cfg.get('zeusx_key')
        mailbox_class = ZeusXProvider
    elif service == 'a':
        key = cfg.get('afham_mail_api9_key', '')
        mailbox_class = AfhamMailProvider
    elif service == 'd':
        key = cfg.get('duckmail_key', '')
        mailbox_class = DuckMailProvider
    elif service == 'r':
        key = cfg.get('crowmail_key', '')
        mailbox_class = CrowMailProvider
    else:
        key = cfg.get('cybertemp_key')
        mailbox_class = MailboxClient

    if not key and service not in ('d',):
        log_event("WARNING", f"API key not found for service '{service.upper()}'. Please review config.yaml.")

    clear_screen()
    ext_path = await setup_nopecha(log_event)
    
    if len(sys.argv) > 1:
        try:
            target = int(sys.argv[1])
        except:
            target = 1
    else:
        try:
            target = int(prompt_user("Enter target account quantity (0 for infinite): "))
        except:
            target = 1

    custom_display_name = None
    done = 0
    start = time.time()
    valid_count = 0
    locked_count = 0
    invalid_count = 0
    
    try:
        while True:
            if target != 0 and done >= target: break
            done += 1
            log_event("INFO", f"Initiating account creation sequence #{hl(str(done))}...")
            
            try:
                engine = AccountCreator(key, mailbox_class, extension_path=ext_path, custom_display_name=custom_display_name)
                resp = await engine.run()
                
                if resp and len(resp) == 2:
                    token, took = resp
                    if token == "LOCKED":
                        locked_count += 1
                        print_stats_bar(valid_count, locked_count, invalid_count)
                    elif token:
                        log_event("SUCCESS", f"Account generated and verified in {hl(f'{took:.1f}s')}.")
                        valid_count += 1
                        print_stats_bar(valid_count, locked_count, invalid_count)
                        humanize_token(token, names, bios, pronouns, avatar_files, custom_display_name)
                    else:
                        invalid_count += 1
                        log_event("ERROR", f"Account generation sequence #{done} failed.")
                        print_stats_bar(valid_count, locked_count, invalid_count)
                else:
                    invalid_count += 1
                    log_event("ERROR", f"Account generation sequence #{done} failed.")
                    print_stats_bar(valid_count, locked_count, invalid_count)
            except asyncio.CancelledError:
                break
            except Exception as e:
                invalid_count += 1
                log_event("ERROR", f"Runtime exception encountered: {e}")
                print_stats_bar(valid_count, locked_count, invalid_count)
                continue
                
            if target == 1: break
            elif target != 0 and done >= target: break
            else:
                if use_vpn:
                    await rotate_mullvad_ip()
                else:
                    await animated_cooldown(vpn_delay)
                
    except KeyboardInterrupt:
        log_event("SUCCESS", "Execution interrupted by operator. Exiting...")
    finally:
        await shutdown_engine()
        
    elapsed = time.time() - start
    log_event("INFO", f"Successfully generated {hl(str(valid_count))} valid tokens in {hl(f'{elapsed:.1f}')} seconds.")
    prompt_user("Press Enter to exit application...")

if __name__ == '__main__':
    def silent_error(loop, context):
        pass
        
    try:
        if hasattr(asyncio, 'WindowsSelectorEventLoopPolicy'):
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.set_exception_handler(silent_error)
        
        try:
            loop.run_until_complete(main())
        except (asyncio.CancelledError, KeyboardInterrupt):
            pass
        finally:
            loop.close()
    except Exception as e:
        with open("crash.log", "w") as f:
            f.write(f"CRASH: {str(e)}\n\n")
            f.write(traceback.format_exc())
        print(f"CRASH: {str(e)}")
        prompt_user("Press Enter to exit...")
    finally:
        cleanup_resources()